@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <p class="quote">About me</p>
        </div>
    </div>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. A architecto assumenda consequatur enim est eveniet hic, id itaque nisi, nobis quas quis saepe tempore velit voluptatibus? Blanditiis quisquam reiciendis sit.
    </p>
@endsection